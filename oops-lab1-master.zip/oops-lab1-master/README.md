# oops-lab1
easy and general programs in C language ( Btech 3rd semester)
