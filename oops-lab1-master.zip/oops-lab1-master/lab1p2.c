#include<stdio.h>
int main()
{
int n,r,d=0;
scanf("%d",&n);
while(n!=0)
{
r=n%10;
d++;
n=n/10;
}
printf("%d\n",d);
}
