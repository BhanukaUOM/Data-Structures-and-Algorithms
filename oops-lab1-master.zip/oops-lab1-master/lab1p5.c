#include<stdio.h>
#include<string.h>
int main()
{
    char s[10];
    int i,l=0;
    gets(s);
l=strlen(s);
printf("%d\n",l);
}
