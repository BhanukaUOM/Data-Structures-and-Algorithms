#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
    int i,first=0,second=0,third=0,last=0;
    float num;
    for(i=1000;i<=9999;i++)
    {
    	first=i/1000;
    	second=(i/100)%10;
    	third=(i/10)%10;
    	last=i%10;
    num=sqrt(i);
    if((ceil(num)-num==0)&&(first==second)&&(third==last))
        printf("%d\n",i);
}}
