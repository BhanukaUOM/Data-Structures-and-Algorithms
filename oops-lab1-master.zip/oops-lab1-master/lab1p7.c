#include<stdio.h>
#include<string.h>
int main()
{
    char s[10],t[10];
    int i,l1=0,l2=0,length=0;
    gets(s);
    gets(t);
    l1=strlen(t);
    l2=strlen(s);
    for(i=l1-1;i>=0;i--)
    {
        if(s[l2-1]==t[i])
        {
            l2--;
            length++;
        }
    }
    if(length==l1)
        printf("1\n");
    else
        printf("0\n");
}
