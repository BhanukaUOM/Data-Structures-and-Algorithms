#include<stdio.h>
#include<string.h>
int main()
{
    char s[30],t[10];
    int l1=0,l2=0,i;
    gets(s);
    gets(t);
    l1=strlen(s);
    l2=strlen(t);
    for(i=0;i<=l2;i++)
    {
        s[l1++]=t[i];
    }
    puts(s);
}
